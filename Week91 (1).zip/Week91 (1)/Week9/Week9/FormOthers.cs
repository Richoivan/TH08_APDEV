﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week9
{

    public partial class FormOthers : Form
    {
        FormMain formmain;
        public FormOthers()
        {
            InitializeComponent();
        }
        public void FormThis(FormMain formthis)
        {
            this.formmain = formthis;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                formmain.ItemAdd(textBox1.Text, Convert.ToInt32(textBox2.Text));
            }
            else
            {
                MessageBox.Show("Please Fill Everything");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string imagedirectory = "";
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "jpg files(.*jpg)|*.jpg| PNG files(.*png)|*.png| All Files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imagedirectory = dialog.FileName;
                pictureBox2.ImageLocation = imagedirectory;
            }

            
                textBox1.Enabled = true;
                textBox2.Enabled = true;
            button3.Enabled = true;
            
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Image = null;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            button3.Enabled = false;
        }
    }
}
