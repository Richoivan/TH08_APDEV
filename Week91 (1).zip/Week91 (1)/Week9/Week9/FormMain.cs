using System.Data;
using System.Windows.Forms;

namespace Week9
{
    public partial class FormMain : Form
    {
        DataTable dt = new DataTable();
        bool deleted = false;

        public void ItemAdd(string itemname, int cost)
        {
            int quantity = 1;
            bool itemincart = false;
            int id = 0;
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i][0].ToString() == itemname)
                {
                    int additionalquantity = Convert.ToInt32(dt.Rows[i][1].ToString());
                    quantity = quantity + additionalquantity;
                    itemincart = true;
                    break;
                }
                id++;
            } 

            if (itemincart)
            {
                dt.Rows[id][1] = quantity;
                dt.Rows[id][3] = quantity * cost;
            }
            else
            {
                dt.Rows.Add(itemname,1,cost,cost);
            }

            if (dt.Rows.Count != 0)
            {
                int subtotal = 0;
                try
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dt.Rows[i][3].ToString());
                    }
                }
                catch
                {

                }

                tb_st.Text = subtotal.ToString();
                tb_t.Text = (subtotal + (subtotal / 10)).ToString();
            }
        }
        public FormMain()
        {
            InitializeComponent();
            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");
            dgv.DataSource = dt;
            dgv.ReadOnly= true;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            tb_st.ReadOnly = true;
            tb_t.ReadOnly = true;
        }

        private void topWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void bottomWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void acceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOthers form = new FormOthers();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }

        private void dgv_CellStateChanged(object sender, DataGridViewCellStateChangedEventArgs e)
        {
            
        }

        private void dgv_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dgv_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            if (dt.Rows.Count !=0)
            {
                int subtotal = 0;
                try
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        subtotal += Convert.ToInt32(dt.Rows[i][3].ToString());
                    }
                }
                catch
                {

                }

                tb_st.Text = subtotal.ToString();
                tb_t.Text = (subtotal + (subtotal / 10)).ToString();
            }


        }

        private void dgv_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back && dt.Rows.Count > 0)
            {
                dt.Rows[dgv.CurrentCell.RowIndex].Delete();
            }

            int subtotal = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                subtotal += Convert.ToInt32(dt.Rows[i][3].ToString());
            }
            tb_st.Text = subtotal.ToString();
            tb_t.Text = (subtotal + (subtotal / 10)).ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dt.Rows.Count > 0)
            {
                dt.Rows[dgv.CurrentCell.RowIndex].Delete();
            }

            int subtotal = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                subtotal += Convert.ToInt32(dt.Rows[i][3].ToString());
            }
            tb_st.Text = subtotal.ToString();
            tb_t.Text = (subtotal + (subtotal / 10)).ToString();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTShirt form = new FormTShirt();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormShirt form = new FormShirt();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPants form = new FormPants();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLPants form = new FormLPants();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormShoes form = new FormShoes();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }

        private void jewelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormJewel form = new FormJewel();
            form.Dock = DockStyle.Top;
            form.FormBorderStyle = FormBorderStyle.None;
            form.TopLevel = false;
            form.FormThis(this);

            pnlmain.Controls.Clear();
            pnlmain.Controls.Add(form);
            form.Show();
        }
    }
}